/**
 * This is a JavaScript test2 file.
 */
var bar = "foo";
